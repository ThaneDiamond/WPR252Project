//just have to make a new folder under public and link the image in homepage.ejs, if you can use ejs thats great but if not html works too. ty and gl
require("dotenv").config()

const express = require("express")
const {response} = require ("express")
const app = express()

const PORT = process.env.PORT
const HOST = process.env.HOST

app.set("view engine","ejs")
app.use(express.static("public"))
app.use(express.urlencoded())

app.get("/",(request,response) => {
    response.render("homepage")
})

app.listen(PORT,HOST,() => {
    console.log(`website is running at PORT:${PORT}`)
})
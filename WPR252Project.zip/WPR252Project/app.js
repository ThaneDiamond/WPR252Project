require("dotenv").config()

fs = require("fs")
const express = require("express")
const {response, request} = require ("express")
const app = express()

const PORT = process.env.PORT
const HOST = process.env.HOST

app.set("view engine","ejs")
app.use(express.static("public"))
app.use(express.urlencoded())

app.get("/",(request,response) => {
    response.render("homepage")
})

let filepath = "/pdf/CV.pdf"
app.get("/CV",(request,response)=> {
    fs.readFile(__dirname+filepath,(err,data)=>{
        response.contentType("application/pdf")
        response.send(data)
    })
})


app.listen(PORT,HOST,() => {
    console.log(`website is running at PORT:${PORT}`)
})